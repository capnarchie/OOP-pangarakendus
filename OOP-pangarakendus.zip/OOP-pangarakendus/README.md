# OOP-pangarakendus
OOP kursuse projekt

Loo oma branch ja tee muudatusi seal, kui kõik töötab võid pull request teha / masterisse pushida.
